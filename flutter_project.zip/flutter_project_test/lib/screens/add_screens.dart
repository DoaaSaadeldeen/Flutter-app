import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_project_test/models/NotesOperation.dart';
import 'package:flutter_project_test/models/NotesOperation.dart';
import 'package:provider/provider.dart';

class AddScreen extends StatelessWidget{
  String title_text="",description_text="";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.pinkAccent ,
      appBar: AppBar(
        title:Text('NotesHelper') ,
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.pink,
      ),
      body: Padding(
        padding:const EdgeInsets.all(20) ,
        child: Column(
          children: [
            TextField(
              decoration: InputDecoration(
                border:InputBorder.none ,
                hintText:'Enter title' ,
                hintStyle:TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),

              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              onChanged: (value){
                title_text=value;
              },
            ),

            Expanded(
              child: TextField(
                decoration: InputDecoration(
                  border:InputBorder.none ,
                  hintText:'Enter description' ,
                  hintStyle:TextStyle(
                    fontSize: 17,
                    color: Colors.white,
                  ),
                ),

                style: TextStyle(
                  fontSize: 17,
                  color: Colors.white,
                ),
                onChanged: (value){
                  description_text=value;
                },
              ),
            ),
            FlatButton(
              onPressed: (){
                Provider.of<NotesOperation>(context, listen: false).addNewNote(
                    title_text, description_text);
                Navigator.pop(context);
              },
              color:Colors.white,
              child:Text(
                'add note',
                style:TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color:  Colors.pink
                ),
              ),
            ),
          ],
        ),

      ),
    );
  }

}