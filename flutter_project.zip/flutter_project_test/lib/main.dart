import 'package:flutter/material.dart';
import 'package:flutter_project_test/models/NotesOperation.dart';
import 'package:flutter_project_test/screens/home_screens.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<NotesOperation>(
      create: (context)=>NotesOperation(),
      child: MaterialApp(
        home: HomeScreen(),

      ),
    );
  }
  static saveStr(String key, String message) async {
    final SharedPreferences pref = await SharedPreferences.getInstance();
    pref.setString(key, message);
  }
}


