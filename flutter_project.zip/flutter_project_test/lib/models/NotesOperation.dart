import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'Note.dart';
class NotesOperation extends ChangeNotifier {
 static SharedPreferences prefs;
  //Notes List
  List<Note> _notes = new List<Note>();

  List<Note> get getNotes{
    return _notes;
  }

  NotesOperation(){
    addNewNote("first note", 'first note description');
// retrive old data
 // readPrefStr("notes");
  
  }// function to add data to list of notes
  void addNewNote(String title,String descriptions)
  {
    if(title!="" && descriptions!="") {
      Note note = new Note(title, descriptions);
      _notes.add(note);
     // saveStr("notes", note.title);
      notifyListeners();
    }

  }

  // function to remove or delete notes by using list index position
  void removeNotes(int index)
  {
    _notes.removeAt(index);
    notifyListeners();
  }


  /*
  static readPrefStr(String key) async {

   // SharedPreferences prefs;
    String userName = prefs.getString("notes") ?? "_";
    if (userName == "_"){
       prefs = await SharedPreferences.getInstance();
      return prefs.getString(key);

    }
    // this is a new user, no data found
    else{
      return prefs.getString(key);

    }
      // there exist a data in prefs


  }

  static saveStr(String key, String message) async {
   // SharedPreferences prefs;
    String userName = prefs.getString("notes") ?? "_";
    if (userName == "_"){
      prefs = await SharedPreferences.getInstance();
      prefs.setString(key, message);

    }else{
      prefs.setString(key, message);
    }
    // this is a new user, no data found
       // there exist a data in prefs

  }
*/

}