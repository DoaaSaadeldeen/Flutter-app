class Note{
  String title;
  String description;
  Note(this.title,this.description);
}